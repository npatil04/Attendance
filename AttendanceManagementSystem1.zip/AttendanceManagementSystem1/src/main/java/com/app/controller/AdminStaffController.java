package com.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.model.Leave;
import com.app.model.User;
import com.app.service.UserService;
import com.google.gson.Gson;

/**
 * @author narpatil
 *
 */
@Controller
public class AdminStaffController 
{
  @Autowired
  public UserService userService;
  
  /**
   * @return
   */
  @RequestMapping(value="/getEmpLeaveInfo",method = RequestMethod.POST)
  public @ResponseBody String getdata() {
    System.out.println("Leaves");

    List<Leave> leaveList = userService.getAppliedLeaveEmployees();

    Gson gson = new Gson();    //Gson is java API from google which convert gson to json object and vice versa.
    if (leaveList.size() == 0) {
      return "[{}]";
    }

    String jsonFormatData = gson.toJson(leaveList);
   System.out.println(jsonFormatData);
    return jsonFormatData;

  }

  /**
   * @param empid
   * @param leavid
   * @param status
   * @return
   */
  @RequestMapping(value = "/approveLeaveById", method = RequestMethod.POST)
  public @ResponseBody String approveapproveLeaveByIdLeave(@RequestParam("empId") int empid, @RequestParam("leaveId") int leavid,
      @RequestParam("approved") boolean status) 
  {

    System.out.println(empid + " : " + leavid + "" + status);

    userService.approveLeave(empid, leavid, status);
    return null;
  }

  /**
   * @param empid
   */
  @RequestMapping(value = "/updateEmpLopInfo", method = RequestMethod.POST)
  public @ResponseBody void updateEmpLop(@RequestParam("empId") int empid) {
    System.out.println("Leaves" + empid);
    userService.calculateLop(empid);

    Gson gson = new Gson();

  }
  
}
