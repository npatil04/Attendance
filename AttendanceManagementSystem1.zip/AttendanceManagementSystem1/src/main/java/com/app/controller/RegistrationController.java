package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.User;
import com.app.service.UserService;

/**
 * @author narpatil
 *
 */
@Controller
public class RegistrationController 
{
  @Autowired
  public UserService userService;

  /**
   * @param request
   * @param response
   * @return
   */
  @RequestMapping(value = "/AdminRegister", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) // Here ModelAndView is a
                                                                                             // class
  {
    ModelAndView mav = new ModelAndView("AdminRegister");
    mav.addObject("user", new User());
    // System.out.println("hii user");
    return mav;
  }

  /**
   * @param user
   * @param bindingResult
   * @param session
   * @return
   */
  
  @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
  public ModelAndView addUser(@ModelAttribute("user") User user, BindingResult bindingResult, HttpSession session) {
    user.setUserGroup(1);
    userService.register(user);
    session.setAttribute("registrationsuccesfull", "Registration Successfull your ID is " + user.getEmpid());
    return new ModelAndView("AdminRegister");
  }
}
