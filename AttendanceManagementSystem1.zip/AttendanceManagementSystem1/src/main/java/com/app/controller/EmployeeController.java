package com.app.controller;

import java.text.DateFormatSymbols;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.coyote.http2.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.Leave;
import com.app.model.LossOfPay;
import com.app.model.User;
import com.app.model.work;
import com.app.service.UserService;
import com.google.gson.Gson;

/**
 * @author narpatil
 *
 */
@Controller
public class EmployeeController {
  @Autowired
  public UserService userService;

  /**
   * @return
   */
  @RequestMapping(value = "/ApplyLeave", method = RequestMethod.GET)
  public ModelAndView showRegister() {
    ModelAndView mav = new ModelAndView("ApplyLeave");
    mav.addObject("leave", new Leave());

    return mav;
  }

  /**
   * @param leave
   * @param bindingResult
   * @param session
   * @return
   */
  @RequestMapping(value = "/applyleave", method = RequestMethod.POST)
  public ModelAndView addUser(@ModelAttribute("leave") Leave leave, BindingResult bindingResult, HttpSession session) 
  {
    User user = (User) session.getAttribute("user");

    System.out.println("daoooo demo" + leave);

    System.out.println(session.getAttribute("id"));

    User user1 = userService.getUserByID((Integer) session.getAttribute("id"));
    int availableleave = user1.getLeavecount();

    System.out.println(availableleave);

    ModelAndView mav = new ModelAndView("ApplyLeave");
    System.out.println(availableleave - leave.getDays());   
    
    if ((availableleave - leave.getDays()) >= -7) 
    {
      userService.applyLeave(leave, (Integer) session.getAttribute("id"));
      userService.updateEmployeeLeave(user);

      mav.addObject("leave", new Leave());
      session.setAttribute("appliedsuccessfully", "Leave Applied Successfuly..");

    }

    else {
      
      session.setAttribute("rejected", "Your leave has been excedded limit of leaves..");

    }

    return mav;
  }

  /**
   * @return
   */
  @RequestMapping(value = "/ViewAttendance", method = RequestMethod.GET)
  public ModelAndView viewAttendane() {
    ModelAndView mav = new ModelAndView("ViewAttendance");
    mav.addObject("leave", new Leave());

    return mav;
  }

  /**
   * @param leave
   * @param bindingResult
   * @param session
   * @return
   */
  @RequestMapping(value = "/viewattendance", method = RequestMethod.POST)
  public ModelAndView viewEmpAttendance(@ModelAttribute("leave") Leave leave, BindingResult bindingResult,
      HttpSession session) {

    ModelAndView mav = new ModelAndView("ViewAttendance");
    mav.addObject("leave", new Leave());

    return mav;
  }

  /**
   * @return
   */
  @RequestMapping(value = "/AttendanceForm", method = RequestMethod.GET)
  public ModelAndView Attendanceform() {
    ModelAndView mav = new ModelAndView("AttendanceForm");
    mav.addObject("attendance", new Leave());

    return mav;
  }

  /**
   * @param leave
   * @param bindingResult
   * @param session
   * @return
   */
  @RequestMapping(value = "/addattendance", method = RequestMethod.POST)
  public ModelAndView addattendance(@ModelAttribute("attendance") Leave leave, BindingResult bindingResult,
      HttpSession session) {
    User user = (User) session.getAttribute("user");
    userService.applyLeave(leave, user.getEmpid());
    userService.updateEmployeeLeave(user);
    ModelAndView mav = new ModelAndView("AttendanceForm");
    mav.addObject("attendance", new Leave());
    return mav;
  }

  /**
   * @param empid
   * @return
   */

  // To see view lop
  @RequestMapping(value = "/getEmpLopInfo", method = RequestMethod.POST)
  public @ResponseBody String getdata(@RequestParam("empId") int empid) {
    System.out.println("Leaves");

    List<LossOfPay> leaveList = userService.getEmployeeLop(empid);

    Gson gson = new Gson();
    if (leaveList.size() == 0) {
      return "[{}]";
    }

    String jsonFormatData = gson.toJson(leaveList);

    return jsonFormatData;

  }

  // here getapplyleaves is called in viewattendance
  @RequestMapping(value = "/getapplyleaves", method = RequestMethod.GET)
  public @ResponseBody String getapplyleaves(HttpSession session, HttpServletRequest request) {
    System.out.println("Leaves");
    String fromDate;
    int days;
    String toDate;
    Leave leave = new Leave();
    int empid = (Integer) session.getAttribute("id");
    Calendar calendar = new GregorianCalendar(); // Here Calendar class in abstact class and GregorianCalendar is
                                                 // concrete class in java
    List<Leave> leaveList = userService.getapplyleaves(empid);

    // To save the date ( Or to get list of dates which are alreay approved in
    // leaves table)
    List<LocalDate> leavelist1 = new ArrayList<LocalDate>();
    System.out.println(leaveList);
    Iterator<Leave> itr = leaveList.iterator();
    Iterator<Leave> itr1 = leaveList.iterator();

    // we need to use to itereator for traversing multiple values
    while (itr.hasNext()) {

      LocalDate start = LocalDate.parse(itr.next().getFromDate()); // here start get
      LocalDate end = LocalDate.parse(itr1.next().getToDate()); // End date
      List<LocalDate> totalDates = new ArrayList<LocalDate>();

      // Here we are traversing the start to to date in datepicker (From 17/12/2019 to
      // 23/12/2019)

      while (!start.isAfter(end)) {
        totalDates.add(start);
        leavelist1.add(start);
        start = start.plusDays(1); // here increment goes forward of date
      }
    }

    System.out.println(leavelist1);

    Gson gson = new Gson();
    if (leaveList.size() == 0) {
      return "[{}]";
    }

    String jsonFormatData = gson.toJson(leavelist1);

    List<work> leavelist = userService.getapplyleavesbygroup(empid);

    request.setAttribute("leavelist", leavelist);   //here leavelist is getting passed into view attendance form

    return jsonFormatData;

  }

  @RequestMapping(value = "/getattendance", method = RequestMethod.GET)
  public ModelAndView getattendance(HttpSession session, HttpServletRequest request) throws ParseException {

    int empid = (Integer) session.getAttribute("id");

    List<work> leavelist = userService.getapplyleavesbygroup(empid);

    Iterator<work> w = leavelist.iterator();

    while (w.hasNext()) {
      int day = w.next().getDays();
      System.out.println(day);

    }

    request.setAttribute("leavelist", leavelist);
    ModelAndView mav = new ModelAndView("ViewAttendance");
    mav.addObject("leave", new Leave());
    return mav;
  }

}
