package com.app.controller;

public enum DateTimeConstants {
  SUNDAY,SATURDAY,FRIDAY
}
