package com.app.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.Login;
import com.app.model.User;
import com.app.service.UserService;

/**
 * @author narpatil
 *
 */
@Controller
public class AdminStaffLoginController {
  @Autowired
  UserService userService;

  /**
   * @param request
   * @param response
   * @return mav
   */
  @RequestMapping(value = "/AdminStaffLogin", method = RequestMethod.GET)
  public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("AdminStaffLogin");
    mav.addObject("adminlogin", new Login());
    return mav;
  }

  /**
   * @param session
   * @param request
   * @param response
   * @param login
   * @return
   */
  @RequestMapping(value = "/AdminStaffloginProcess", method = RequestMethod.POST)
  public ModelAndView loginProcess(HttpSession session, HttpServletRequest request, HttpServletResponse response,
      @ModelAttribute("adminlogin") Login login) {
    ModelAndView mav = null;

    User user = userService.validateUser(login);

    if (null != user && (user.getUserGroup() == 2)) {
      mav = new ModelAndView("AdminStaffLoginDashboard");

      session.setAttribute("user", user);
      mav.addObject("user", new User());
      session.setAttribute("welcomemessage", "Welcome " + user.getUsername() + "");
      session.setAttribute("user", user);
    }

    else 
    {
      mav = new ModelAndView("AdminStaffLogin");
      System.out.println(mav);
      session.setAttribute("message", "Username or Password is wrong!!");

    }

    return mav;
  }

}
