package com.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.Login;
import com.app.model.User;
import com.app.service.UserService;
import com.google.gson.Gson;

/**
 * @author narpatil
 *
 */
@Controller
public class AdminController 
{
  @Autowired
  public UserService userService;

  // For adding Employee
  /**
   * @param request
   * @param response
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) // Here ModelAndView is a                                                                                         // class
  {
    ModelAndView mav = new ModelAndView("");
    mav.addObject("user", new User());
    return mav;
  }

  /**
   * @param user
   * @param bindingResult
   * @param session
   * 
   * 
   * @return
   */
  @RequestMapping(value = "/empRegisterProcess", method = RequestMethod.POST)
  public ModelAndView addUser(@ModelAttribute("user") User user, BindingResult bindingResult, HttpSession session) {
    user.setUserGroup(3);
    userService.register(user);
    session.setAttribute("addsuccessful", "Last Successfully added ID is " + user.getEmpid());
    return new ModelAndView("AdminDashboard", "firstname", user.getFirstname());
  }
  
  
  @RequestMapping(value = "/empEditdata", method = RequestMethod.POST)
  public ModelAndView editUser(@ModelAttribute("user") User user, BindingResult bindingResult, HttpSession session) {
    user.setUserGroup(3);
    userService.register(user);
    session.setAttribute("editsuccessful", "Data is updated Successfully of Id " + user.getEmpid());
    return new ModelAndView("AdminDashboard", "firstname", user.getFirstname());
  }
  
  
  
  

  //
  /**
   * @param model
   * @return
   */
  @RequestMapping(value = "/AdminDashboard", method = RequestMethod.GET)
  public String show(Model model) {

    model.addAttribute("user", new User());
    return "AdminDashboard";
  }

  /**
   * @return
   */
  @RequestMapping(value = "/getdata", method = RequestMethod.POST)
  public @ResponseBody String getdata() 
  {
    List<User> userlist = userService.getEmployee();
    
    Map<Integer, User> excelmap = new HashMap<Integer,User>();
    
    
    for (User user : userlist) {
      excelmap.put(user.getEmpid(), user);
    }
    
    Set<Entry<Integer, User>> excelSet = excelmap.entrySet();
    Iterator itr = excelSet.iterator();
   while (itr.hasNext()) 
   {
     System.out.println(itr.next().toString());
   
    
  }
    
    Gson gson = new Gson();   //GSON is the java Api of google which is used to convert the gson to json object and vice versa
    if (userlist.size() == 0) {
      return "[{}]";
    }

    String jsonFormatData = gson.toJson(userlist);

    return jsonFormatData;

  }

  
  
  
  
  
  
  

  /**
   * @param empid
   * @return
   */
  
  
  @RequestMapping(value = "/deleteById", method = RequestMethod.POST)
  public @ResponseBody String deleteById(@RequestParam("empId") int empid) // Here ModelAndView is a class

  {
    userService.deleteEmpById(empid);
    return null;
  }
}
