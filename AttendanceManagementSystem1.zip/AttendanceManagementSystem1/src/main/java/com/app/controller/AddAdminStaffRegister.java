package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.app.model.User;
import com.app.service.UserService;
import com.google.gson.Gson;

@Controller
public class AddAdminStaffRegister 
{
  
  @Autowired
  public UserService userService;
  /**
   * @param request
   * @param response
   * @return
   */
  @RequestMapping(value = "AddAdminStaff", method = RequestMethod.GET)
  public ModelAndView showAdminStaffRegister(HttpServletRequest request, HttpServletResponse response) // Here
                                                                                                       // ModelAndView
                                                                                                       // is a class
  {
    ModelAndView mav = new ModelAndView("AddAdminStaff");
    mav.addObject("user", new User());
    return mav;
  }

  /**
   * @param user
   * @param bindingResult
   * @param session
   * @return
   */
  @RequestMapping(value = "/adminstaffRegisterProcess", method = RequestMethod.POST)
  public ModelAndView addAdminStaff(@ModelAttribute("user") User user, BindingResult bindingResult,
      HttpSession session) {
    System.out.println("hii");
    user.setUserGroup(2);
    userService.register(user);
    session.setAttribute("registrationsuccesfull", "Last Successfully added ID is " + user.getEmpid());
    return new ModelAndView("AddAdminStaff");
  }

 
  
  /**
   * @return
   */
  
}
