package com.app.model;

public class work {

  private String month;
  private int days;

  public String getMonth() {
    return month;
  }

  public void setMonth(String month) {
    this.month = month;
  }

  public int getDays() {
    return days;
  }

  public void setDays(int days) {
    // TODO Auto-generated method stub
    this.days = days;
  }

}
