package com.app.model;

/**
 * @author narpatil
 *
 */
public class Leave {
  public Leave() {
  }

  private int leaveId;

  private String remark;

  private String fromDate;

  private String toDate;

  private int empId;

  private int days;

  public void setLeaveId(int leaveId) {
    this.leaveId = leaveId;
  }

  public int getLeaveId() {
    return leaveId;
  }

  public int getEmpId() {
    return empId;
  }

  public void setEmpId(int empId) {
    this.empId = empId;
  }

  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  public String getFromDate() {
    return fromDate;
  }

  public void setFromDate(String fromDate) {
    this.fromDate = fromDate;
  }

  public String getToDate() {
    return toDate;
  }

  public void setToDate(String toDate) {
    this.toDate = toDate;
  }

  @Override
  public String toString() {
    return "Leave [leaveId=" + leaveId + ", remark=" + remark + ", fromDate=" + fromDate + ", toDate=" + toDate
        + ", noOfDays=" + days + ", empId=" + empId + "]";
  }

  public int getDays() {
    return days;
  }

  public void setDays(int days) {
    this.days = days;
  }

}
