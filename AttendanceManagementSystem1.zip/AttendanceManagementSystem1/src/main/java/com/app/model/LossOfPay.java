package com.app.model;

/**
 * @author narpatil
 *
 */
public class LossOfPay {

  private int empId;

  private int lop;

  public int getEmpId() {
    return empId;
  }

  public void setEmpId(int empId) {
    this.empId = empId;
  }

  public int getLop() {
    return lop;
  }

  public void setLop(int lop) {
    this.lop = lop;
  }

  @Override
  public String toString() {
    return "LossOfPay [empId=" + empId + ", lop=" + lop + "]";
  }
  
  

}
