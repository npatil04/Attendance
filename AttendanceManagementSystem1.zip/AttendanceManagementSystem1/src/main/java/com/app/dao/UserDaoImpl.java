package com.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.app.model.Leave;
import com.app.model.Login;
import com.app.model.LossOfPay;
import com.app.model.User;
import com.app.model.work;

/**
 * @author narpatil
 *
 */
public class UserDaoImpl implements UserDao {
  @Autowired
  DataSource datasource;

  @Autowired
  JdbcTemplate jdbcTemplate;

  //To add employees and update employees
  public void register(User user) 
  {
    
    String sql1 = "select * from user where empid=" + user.getEmpid() ;
    
    List<User> users = jdbcTemplate.query(sql1, new UserMapper());
    
    if(users.size()> 0)
    {
      String sql = "update user set empid="+user.getEmpid()+" , username='"+user.getUsername()+"' , password='"+user.getPassword()+"' , firstname='"+user.getFirstname()+"' , lastname='"+user.getLastname()+"' , email='"+user.getEmail()+"' ,address='"+user.getAddress()+"' , phone='"+user.getPhone()+"' , userGroup='"+user.getUserGroup()+"' , leavecount="+user.getLeavecount()+" where empid="+user.getEmpid()+"";
      jdbcTemplate.update(sql);      
    }
    
    else
    {
      String sql = "insert into user (empid,username,password,firstname,lastname,email,address,phone,usergroup,leavecount) values(?,?,?,?,?,?,?,?,?,?)";
      jdbcTemplate.update(sql,
          new Object[] { user.getEmpid(), user.getUsername(), user.getPassword(), user.getFirstname(), user.getLastname(),
              user.getEmail(), user.getAddress(), user.getPhone(), user.getUserGroup(),user.getLeavecount() });

    }
  
  
  }

  //For login
  public User validateUser(Login login) 
  {
    String sql = "select * from user where username='" + login.getUsername() + "' and password='" + login.getPassword()
        + "'";

    List<User> users = jdbcTemplate.query(sql, new UserMapper());

    return users.size() > 0 ? users.get(0) : null;
  }

  
  // To view data of employee
  public List<User> getEmployee() 
  {
    String sql = "select * from user where usergroup=3";
    List<User> users = jdbcTemplate.query(sql, new UserMapper());
    return users;
  }
  

  // To delete employee
  public void deleteEmpById(int id) 
  {
    String sql = "delete from user where empid =  " + id;
    jdbcTemplate.execute(sql);  //execute is method of  jdbcTemplate class in java
  }
  
 //Apply Leave 
 public void applyLeave(Leave leave,int empid)
  {
   System.out.println(empid);
    String sql = "insert into leaves(leaveid,empid,reason,status,fromDate,toDate,days) values(?,?,?,?,?,?,?)";
    DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
    
    try 
    {
      Date startDate = df.parse(leave.getFromDate());
      Date endDate = df.parse(leave.getToDate());
      jdbcTemplate.update(sql,
          new Object[] {0,empid,leave.getRemark(),"applied",new Timestamp(startDate.getTime()),new Timestamp(endDate.getTime()),leave.getDays()});
    } 
    catch (ParseException e) 
    {
     
      e.printStackTrace();
    }
  
}


class UserMapper implements RowMapper<User> 
{
  public User mapRow(ResultSet rs, int arg1) throws SQLException 
  {
    User user = new User();

    user.setEmpid(rs.getInt("Empid"));
    user.setUsername(rs.getString("username"));
    user.setPassword(rs.getString("password"));
    user.setFirstname(rs.getString("firstname"));
    user.setLastname(rs.getString("lastname"));
    user.setEmail(rs.getString("email"));
    user.setAddress(rs.getString("address"));
    user.setPhone(rs.getString("phone"));
    user.setLeavecount(rs.getInt("leavecount"));
    user.setUserGroup(rs.getInt("usergroup"));
    user.setDateofjoing(rs.getString("dateofjoing"));
    return user;
  }
}


class getallleaves implements RowMapper<Leave>
{
  public Leave mapRow(ResultSet rs, int arg1) throws SQLException 
  {
    Leave leave=new Leave();

    leave.setEmpId(rs.getInt("Empid"));
    leave.setFromDate(rs.getString("Fromdate"));
    leave.setFromDate(rs.getString("Todate"));
    return leave;
  }
  
  
}

class LeaveMapper implements RowMapper<Leave> 
{
  public Leave mapRow(ResultSet rs, int arg1) throws SQLException 
  {
    Leave leave = new Leave();

   leave.setEmpId(rs.getInt("Empid"));
   Format formatter = new SimpleDateFormat("yyyy-MM-dd");
   leave.setDays(rs.getInt("days"));
   leave.setLeaveId(rs.getInt("leaveid"));
   leave.setFromDate(rs.getString("Fromdate"));
   leave.setToDate(rs.getString("Todate"));
   leave.setRemark(rs.getString("Reason"));
    return leave;
  }
  
}

class WorkMapper implements RowMapper<work> {

  public work mapRow(ResultSet rs, int arg1) throws SQLException 
  {
    work wk = new work();
    
   wk.setDays(rs.getInt("days"));
   System.out.println(wk.getDays());
   wk.setMonth(rs.getString("month"));
   return wk;
  }
  
}



class LopMapper implements RowMapper<LossOfPay> 
{

  public LossOfPay mapRow(ResultSet rs, int arg1) throws SQLException 
  {
    LossOfPay lop = new LossOfPay();
    lop.setEmpId(rs.getInt("Empid"));
    lop.setLop(rs.getInt("lop"));
    return lop;
  }
}

//View leaves in adminStaff panel
public List<Leave> getAppliedLeaveEmployees() {
  String sql = "select * from leaves where Status = 'applied' ";
  return jdbcTemplate.query(sql, new LeaveMapper());
}


public Leave getLeaveByID(int id)
{
  String sql = "select * from leaves where leaveid ="+id;
  if(jdbcTemplate.query(sql, new LeaveMapper()).get(0)!=null)
      
    return jdbcTemplate.query(sql, new LeaveMapper()).get(0);
  else
     return null;
}








//Here leavecount get decrese when admin staff approve the leave
public int updateEmployeeLeave(User user,long noOfDays) 
{
 
  System.out.println(user.getEmpid()+":"+noOfDays);
  System.out.println("daysss"+noOfDays);
  
  String sql = "update user set leavecount=? where Empid=?";
  return jdbcTemplate.update(sql,
      new Object[] {user.getLeavecount()-noOfDays,user.getEmpid()});
  
  
  
}
//To show the data in update attendace form
public User getUserByID(int id) 
{
  String sql = "select * from user where Empid="+id;
  List<User> users = jdbcTemplate.query(sql, new UserMapper());
  if(users!=null)
    return users.get(0);
  else
  return null;
}



public int updateLeaveStatus(int id,String status)
{
  String sql = "update leaves set Status=? where leaveid=?";
   return jdbcTemplate.update(sql,new Object[] {status,id});
}


//calculating the diif between 2 dates
public void approveLeave(int empid,int leaveid,boolean status)
{
  System.out.println("callwed");
  if(status) {
    try {
      Leave leave=getLeaveByID(leaveid);
      User user=getUserByID(empid);
      Date startDate=new SimpleDateFormat("yyyy-MM-dd").parse(leave.getFromDate());   
      Date endDate=new SimpleDateFormat("yyyy-MM-dd").parse(leave.getToDate());
      long diff = endDate.getTime() - startDate.getTime();
      long noOfDays=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
      noOfDays=noOfDays+1;
      if(noOfDays==0)
      {
        
        noOfDays = 1;
      }
      if(updateEmployeeLeave(user, noOfDays)!=0)
        
      updateLeaveStatus(leaveid,"approved");
     // 
     
    } catch (ParseException e) {
     
      e.printStackTrace();
    }  
      
  }else{
    updateLeaveStatus(leaveid,"rejected");
  }
    
}

public void updateEmployeeLeave(User user) {
  // TODO Auto-generated method stub
  
}

//For calculating lop
public List<Leave> getApprovedLeaveEmployees(int empid) {
  String sql = "select * from leaves where Status = 'approved' and Empid="+empid;
  return jdbcTemplate.query(sql, new LeaveMapper());
 }





//For updating lop or inserting lop
public void calculateLop(int empid,int total)
{
  
  String lopsql = "select * from lop where Empid="+empid;
  if( !(jdbcTemplate.query(lopsql, new LopMapper()).isEmpty())) {
    LossOfPay lopObj=   jdbcTemplate.query(lopsql, new LopMapper()).get(0);
     // System.out.println("gyyyy"+lopObj);
      String sql = "update lop set lop=? where Empid=?";
      jdbcTemplate.update(sql,
          new Object[] {total,lopObj.getEmpId()}); 
  }
  else 
  {
    System.out.println("Hello");
    String sql = "insert into lop values(?,?)";
    jdbcTemplate.update(sql,
        new Object[] {empid,total}); 
  }
  
  
  /*String sql = "insert into lop values(?,?)";
  jdbcTemplate.update(sql,
      new Object[] {empid,total}); */
  
}



//To view LOP
public List<LossOfPay> getEmployeeLop(int empid) {
  String sql = "select * from lop where Empid="+empid;
  return jdbcTemplate.query(sql, new LopMapper());
}


public List<Leave> getapplyleaves(int empid) {
  String sql = "SELECT * FROM leaves where empid="+empid+"  and status='approved'";
  List<Leave> leave = jdbcTemplate.query(sql, new LeaveMapper());
  return leave;
}

//View Attendance in table
public List<work> getapplyleavesbygroup(int empid) 
{ 
  System.out.println(empid);
  String sql = "SELECT days,month   FROM work  where empid="+empid ;
  List<work> work = jdbcTemplate.query(sql, new WorkMapper());
  return work;
}




}