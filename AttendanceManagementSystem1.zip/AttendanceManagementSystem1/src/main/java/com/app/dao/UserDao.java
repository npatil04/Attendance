package com.app.dao;

import java.util.List;

import com.app.model.Leave;
import com.app.model.Login;
import com.app.model.LossOfPay;
import com.app.model.User;
import com.app.model.work;

/**
 * @author narpatil
 *
 */
public interface UserDao {

  void register(User user);

  User validateUser(Login login);

  List<User> getEmployee();

  void deleteEmpById(int id);

  public void applyLeave(Leave leave, int empid);

  public void updateEmployeeLeave(User user);

  public List<Leave> getAppliedLeaveEmployees();

  public void approveLeave(int empid, int leaveid, boolean status);

  List<Leave> getApprovedLeaveEmployees(int empid);

  public User getUserByID(int id);

  public void calculateLop(int empid, int total);

  public List<LossOfPay> getEmployeeLop(int empid);
  
  public List<Leave> getapplyleaves(int empid);
  
  public List<work> getapplyleavesbygroup(int empid);
  
}
