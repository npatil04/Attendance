package com.app.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;

import com.app.dao.UserDao;
import com.app.model.Leave;
import com.app.model.Login;
import com.app.model.LossOfPay;
import com.app.model.User;
import com.app.model.work;

/**
 * @author narpatil
 *
 */


public class UserServiceImpl implements UserService {

  @Autowired
  public UserDao userDao;

 
  public void register(User user) {
    userDao.register(user);
  }

  public User validateUser(Login login) {
    return userDao.validateUser(login);
  }

  public List<User> getEmployee() {
    // TODO Auto-generated method stub
    return userDao.getEmployee();
  }

  public void deleteEmpById(int id) {
    userDao.deleteEmpById(id);

  }

  public void applyLeave(Leave leave, int empid) {
    userDao.applyLeave(leave, empid);
  };

  public void updateEmployeeLeave(User user) {
    userDao.updateEmployeeLeave(user);
  }

  public List<Leave> getAppliedLeaveEmployees() {

    return userDao.getAppliedLeaveEmployees();
  }

  public void approveLeave(int empid, int leaveid, boolean status) {
    userDao.approveLeave(empid, leaveid, status);
  }

  public List<Leave> getApprovedLeaveEmployees(int empid) {

    // TODO Auto-generated method stub
    return userDao.getApprovedLeaveEmployees(empid);
  }

  public User getUserByID(int id) {
    return userDao.getUserByID(id);

  }

  
  public void calculateLop(int empid) {
    User user = getUserByID(empid);
    int noOfAvailabelLeaves = user.getLeavecount();
    int paidLeaves = 0;
    if (noOfAvailabelLeaves < 0) paidLeaves = noOfAvailabelLeaves * -1;
    int totalSalary = (30 - paidLeaves) * 1000;   //30-1*1000 = 29000
    userDao.calculateLop(empid, totalSalary);
  }
   
  public List<LossOfPay> getEmployeeLop(int empid) {

    return userDao.getEmployeeLop(empid);
  }

  public List<Leave> getapplyleaves(int empid) {
    // TODO Auto-generated method stub
    return userDao.getapplyleaves(empid);
  }

  public List<work> getapplyleavesbygroup(int empid) {
    // TODO Auto-generated method stub
    return userDao.getapplyleavesbygroup(empid);
  }

}
