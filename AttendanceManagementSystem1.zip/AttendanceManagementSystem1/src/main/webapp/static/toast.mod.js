"use strict";
window.require = function t(e, o, r) {
	function n(a, s) {
		if (!o[a]) {
			if (!e[a]) {
				var p = "function" == typeof require && require;
				if (!s && p)
					return p(a, !0);
				if (i)
					return i(a, !0);
				var u = new Error("Cannot find module '" + a + "'");
				throw u.code = "MODULE_NOT_FOUND", u
			}
			var l = o[a] = {
				exports : {}
			};
			e[a][0].call(l.exports, function(t) {
				var o = e[a][1][t];
				return n(o ? o : t)
			}, l, l.exports, t, e, o, r)
		}
		return o[a].exports
	}
	for (var i = "function" == typeof require && require, a = 0; a < r.length; a++)
		n(r[a]);
	return n
}
		(
				{
					"iqwerty-toast" : [
							function(t, e, o) {
								var r = r || {};
										r.toast = function() {
											function t(o, r, i) {
												if (null !== e())
													t.prototype.toastQueue
															.push({
																text : o,
																options : r,
																transitions : i
															});
												else {
													t.prototype.Transitions = i
															|| n;
													var a = r || {};
															a = t.prototype
																	.mergeOptions(
																			t.prototype.DEFAULT_SETTINGS,
																			a),
															t.prototype.show(o,
																	a),
															a = null
												}
											}
											function e() {
												return i
											}
											function o(t) {
												i = t
											}
											var r = 400, n = {
												SHOW : {
													"-webkit-transition" : "opacity "
															+ r
															+ "ms, -webkit-transform "
															+ r + "ms",
													transition : "opacity " + r
															+ "ms, transform "
															+ r + "ms",
													opacity : "1",
													"-webkit-transform" : "translateY(-100%) translateZ(0)",
													transform : "translateY(-100%) translateZ(0)"
												},
												HIDE : {
													opacity : "0",
													"-webkit-transform" : "translateY(150%) translateZ(0)",
													transform : "translateY(150%) translateZ(0)"
												}
											}, i = null;
											return
													t.prototype.DEFAULT_SETTINGS = {
														style : {
															main : {
																background : "rgba(0, 0, 0, .85)",
																"box-shadow" : "0 0 10px rgba(0, 0, 0, .8)",
																"border-radius" : "3px",
																"z-index" : "99999",
																color : "rgba(255, 255, 255, .9)",
																padding : "10px 15px",
																"max-width" : "60%",
																width : "100%",
																"word-break" : "keep-all",
																margin : "0 auto",
																"text-align" : "center",
																position : "fixed",
																left : "0",
																right : "0",
																bottom : "0",
																"-webkit-transform" : "translateY(150%) translateZ(0)",
																transform : "translateY(150%) translateZ(0)",
																"-webkit-filter" : "blur(0)",
																opacity : "0"
															}
														},
														settings : {
															duration : 4e3
														}
													},
													t.prototype.Transitions = {},
													t.prototype.toastQueue = [],
													t.prototype.timeout = null,
													t.prototype.mergeOptions = function(
															e, o) {
														var r = o;
														for ( var n in e)
															r.hasOwnProperty(n) ? null !== e[n]
																	&& e[n].constructor === Object
																	&& (r[n] = t.prototype
																			.mergeOptions(
																					e[n],
																					r[n]))
																	: r[n] = e[n];
														return r
													},
													t.prototype.generate = function(
															r, n) {
														var i = document
																.createElement("div");
																"string" == typeof r
																		&& (r = document
																				.createTextNode(r)),
																i
																		.appendChild(r),
																o(i),
																i = null,
																t.prototype
																		.stylize(
																				e(),
																				n)
													},
													t.prototype.stylize = function(
															t, e) {
														Object
																.keys(e)
																.forEach(
																		function(
																				o) {
																			t.style[o] = e[o]
																		})
													},
													t.prototype.show = function(
															o, r) {
														this.generate(o,
																r.style.main);
														var n = e();
																document.body
																		.insertBefore(
																				n,
																				document.body.firstChild),
																n.offsetHeight,
																t.prototype
																		.stylize(
																				n,
																				t.prototype.Transitions.SHOW),
																n = null,
																clearTimeout(t.prototype.timeout),
																t.prototype.timeout = setTimeout(
																		t.prototype.hide,
																		r.settings.duration)
													},
													t.prototype.hide = function() {
														var o = e();
																t.prototype
																		.stylize(
																				o,
																				t.prototype.Transitions.HIDE),
																clearTimeout(t.prototype.timeout),
																o
																		.addEventListener(
																				"transitionend",
																				t.prototype.animationListener),
																o = null
													},
													t.prototype.animationListener = function() {
																e()
																		.removeEventListener(
																				"transitionend",
																				t.prototype.animationListener),
																t.prototype.destroy
																		.call(this)
													},
													t.prototype.destroy = function() {
														var r = e();
														if (
																document.body
																		.removeChild(r),
																r = null,
																o(null),
																t.prototype.toastQueue.length > 0) {
															var n = t.prototype.toastQueue
																	.shift();
																	t(
																			n.text,
																			n.options,
																			n.transitions),
																	n = null
														}
													}, {
														Toast : t
													}
										}(), "undefined" != typeof e
												&& (e.exports = r.toast)
							}, {} ]
				}, {}, [ "iqwerty-toast" ]);